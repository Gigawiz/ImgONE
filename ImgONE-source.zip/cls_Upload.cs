﻿using System;
using System.Net;

namespace ImgONE
{
	public class cls_Upload
	{
		#region Imgur
		#endregion
	}
}
