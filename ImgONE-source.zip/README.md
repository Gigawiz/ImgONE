# ImgONE

ImgONE is the official screenshot tool developed for ImgONE.co

This is built on the HyperDesktop2 source code.
